"""Stable provider failure markers for Spark's bounded MCP adapter."""

from __future__ import annotations

from typing import Literal

ProviderErrorCode = Literal[
    "rate-limited",
    "connector-unavailable",
    "provider-rejected",
    "provider-response-invalid",
]


class ProviderError(RuntimeError):
    """A provider failure that is safe to expose as a machine-readable code."""

    def __init__(self, code: ProviderErrorCode) -> None:
        self.code = code
        super().__init__(f"PAPER_SEARCH_MCP_ERROR:{code}")
