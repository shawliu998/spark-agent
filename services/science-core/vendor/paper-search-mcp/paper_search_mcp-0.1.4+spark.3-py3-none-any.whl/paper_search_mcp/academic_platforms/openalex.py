from typing import Any, List, Optional
from datetime import datetime
import json
import requests
import logging
from ..paper import Paper
from .base import PaperSource
from ..utils import extract_doi

logger = logging.getLogger(__name__)


class OpenAlexSearcher(PaperSource):
    """OpenAlex paper search implementation"""

    BASE_URL = "https://api.openalex.org/works"
    MAX_RESPONSE_BYTES = 4 * 1024 * 1024
    USER_AGENT = "Spark-Agent/0.1.4+spark.3 (https://github.com/shawliu998/spark-agent)"

    def __init__(self, session=None):
        self.session = session or requests.Session()
        self.session.headers.update({"User-Agent": self.USER_AGENT, "Accept": "application/json"})

    def _reconstruct_abstract(self, inverted_index: dict) -> str:
        """
        OpenAlex provides abstracts as an inverted index to save space.
        This function reconstructs the original abstract text.
        """
        if not inverted_index:
            return ""
        try:
            word_positions = []
            for word, positions in inverted_index.items():
                for pos in positions:
                    word_positions.append((pos, word))
            # Sort by position
            word_positions.sort(key=lambda x: x[0])
            return " ".join([word for _, word in word_positions])
        except Exception as e:
            logger.warning(f"Error reconstructing OpenAlex abstract: {e}")
            return ""

    def search(self, query: str, max_results: int = 10) -> List[Paper]:
        """
        Search OpenAlex works. Uses the 'search' filter.

        Args:
            query: Search query string
            max_results: Maximum results to return (natively max 200 per page)

        Returns:
            List[Paper]: List of found papers with metadata.
        """
        from ..provider_errors import ProviderError

        # OpenAlex interprets ``?`` and ``*`` as wildcard operators and rejects
        # them in its default stemmed search. Research questions commonly end
        # in ``?``, so remove those unsupported operators before dispatch while
        # preserving all searchable terms.
        search_query = " ".join(query.replace("?", " ").replace("*", " ").split())
        params = {
            "search": search_query,
            "per_page": min(max_results, 200),
        }
        try:
            response = self.session.get(
                self.BASE_URL, params=params, timeout=(10, 30), stream=True
            )
        except requests.RequestException as error:
            raise ProviderError("connector-unavailable") from error

        try:
            if response.status_code == 429:
                raise ProviderError("rate-limited")
            if response.status_code >= 500:
                raise ProviderError("connector-unavailable")
            if response.status_code >= 400:
                raise ProviderError("provider-rejected")

            content_length = response.headers.get("Content-Length")
            if content_length is not None:
                try:
                    if int(content_length) > self.MAX_RESPONSE_BYTES:
                        raise ProviderError("provider-response-invalid")
                except ValueError as error:
                    raise ProviderError("provider-response-invalid") from error

            payload = bytearray()
            try:
                for chunk in response.iter_content(chunk_size=64 * 1024):
                    payload.extend(chunk)
                    if len(payload) > self.MAX_RESPONSE_BYTES:
                        raise ProviderError("provider-response-invalid")
            except requests.RequestException as error:
                raise ProviderError("connector-unavailable") from error
            except TypeError as error:
                raise ProviderError("provider-response-invalid") from error
        finally:
            response.close()

        try:
            data = json.loads(payload)
        except (UnicodeDecodeError, json.JSONDecodeError, TypeError) as error:
            raise ProviderError("provider-response-invalid") from error
        if not isinstance(data, dict) or not isinstance(data.get("results"), list):
            raise ProviderError("provider-response-invalid")

        papers: List[Paper] = []
        results = data["results"]
        malformed = 0
        for item in results:
            paper = self._parse_openalex_item(item)
            if paper is None:
                malformed += 1
                continue
            papers.append(paper)
            if len(papers) >= max_results:
                break
        if results and not papers and malformed:
            raise ProviderError("provider-response-invalid")
        return papers

    def _parse_openalex_item(self, item: Any) -> Optional[Paper]:
        if not isinstance(item, dict):
            return None
        work_id = item.get("id")
        title = item.get("title")
        if not isinstance(work_id, str) or not work_id or not isinstance(title, str) or not title:
            return None

        paper_id = work_id.replace("https://openalex.org/", "")
        authors = []
        authorships = item.get("authorships", [])
        if isinstance(authorships, list):
            for authorship in authorships:
                if not isinstance(authorship, dict):
                    continue
                author = authorship.get("author")
                name = author.get("display_name") if isinstance(author, dict) else None
                if isinstance(name, str) and name:
                    authors.append(name)

        abstract = self._reconstruct_abstract(item.get("abstract_inverted_index"))
        doi = item.get("doi")
        doi = doi.replace("https://doi.org/", "") if isinstance(doi, str) else ""
        if not doi and abstract:
            doi = extract_doi(abstract) or ""

        primary_location = item.get("primary_location")
        primary_location = primary_location if isinstance(primary_location, dict) else {}
        url = primary_location.get("landing_page_url")
        pdf_url = primary_location.get("pdf_url")
        url = url if isinstance(url, str) else work_id
        pdf_url = pdf_url if isinstance(pdf_url, str) else ""
        open_access = item.get("open_access")
        if not pdf_url and isinstance(open_access, dict) and open_access.get("is_oa"):
            oa_url = open_access.get("oa_url")
            pdf_url = oa_url if isinstance(oa_url, str) else ""

        published_date = None
        pub_date_str = item.get("publication_date")
        if isinstance(pub_date_str, str):
            try:
                published_date = datetime.strptime(pub_date_str, "%Y-%m-%d")
            except ValueError:
                pass

        concepts = []
        raw_concepts = item.get("concepts", [])
        if isinstance(raw_concepts, list):
            for concept in raw_concepts:
                name = concept.get("display_name") if isinstance(concept, dict) else None
                if isinstance(name, str) and name:
                    concepts.append(name)
        citations = item.get("cited_by_count", 0)
        citations = citations if isinstance(citations, int) else 0
        return Paper(
            paper_id=paper_id, title=title, authors=authors, abstract=abstract, url=url,
            pdf_url=pdf_url, published_date=published_date, source="openalex",
            categories=concepts[:5], doi=doi, citations=citations,
        )

    def download_pdf(self, paper_id: str, save_path: str) -> str:
        """
        OpenAlex does not host PDFs natively, it only links to open access versions.
        """
        raise NotImplementedError(
            "OpenAlex does not provide direct PDF downloads natively. "
            "Please use the extracted 'pdf_url' if available, or DOI for fallback."
        )

    def read_paper(self, paper_id: str, save_path: str = "./downloads") -> str:
        """
        Not implemented for OpenAlex.
        """
        return (
            "OpenAlex papers cannot be read directly through this aggregator. "
            "Please use the paper's DOI or pdf_url to access the full text."
        )


if __name__ == "__main__":
    searcher = OpenAlexSearcher()
    print("Testing OpenAlex search...")
    papers = searcher.search("CRISPR Cas9 Nature", max_results=3)

    for i, paper in enumerate(papers, 1):
        print(f"\n{i}. {paper.title}")
        print(f"   DOI: {paper.doi}")
        print(f"   URL: {paper.url}")
        print(f"   OA PDF: {paper.pdf_url}")
        print(f"   Citations: {paper.citations}")
        print(f"   Authors: {', '.join(paper.authors[:3])}")
        if paper.abstract:
            print(f"   Abstract: {paper.abstract[:100]}...")
